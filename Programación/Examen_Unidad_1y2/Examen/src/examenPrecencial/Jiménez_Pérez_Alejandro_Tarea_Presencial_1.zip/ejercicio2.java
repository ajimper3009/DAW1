package examenPrecencial;

public class ejercicio2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
	for (int i = 100; i >= 0  ; i -= 1) {
		System.out.println(i);
	}
		
		
		
	}

}
